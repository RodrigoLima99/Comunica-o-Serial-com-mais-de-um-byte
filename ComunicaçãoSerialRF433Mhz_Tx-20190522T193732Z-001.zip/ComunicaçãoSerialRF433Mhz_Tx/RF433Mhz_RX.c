#include <16F877A.h>
#device ADC=10                                                             //Define conversor ADC= 10 bits

#FUSES NOWDT                                                               //Desabilita Watch Dog Timer
#FUSES NOLVP                                                               //No low voltage prgming, B3(PIC16) or B5(PIC18) used for I/O
#FUSES NOBROWNOUT                                                          //N�o reseta por queda na tens�o

#use delay(crystal=20000000)                                               //Define clock 20MHz
#use rs232(baud=1200,parity=N,xmit=PIN_C6,rcv=PIN_C7,bits=8,stream=PORT1)  //Configura a porta serial
int16 Tempo;

#INT_RDA                                                                   //Interrup��o toda vez receber um dado na serial
void  RDA_isr(void) 
{
   putc(getc());                                                           //Envia o que recebeu
   if(tempo++>80)                                                          //Aciona mais ou menos de segundo em segundo       
    {
      output_toggle(pin_d2);                                               //Muda o estado do led(Verifica��o se o programa est� rodando)
      tempo=0;                                                             //Zera a contagem de tempo
    }    
}
void main()                                                                //Fun��o Principal
{
   enable_interrupts(INT_RDA);                                             //Habilita a interrup��o da recep��o de dados
   enable_interrupts(GLOBAL);                                              //Habilita interrup��es global
   while(TRUE)                                                             //Enquanto for Verdadeiro(Loop Infinito)
   {
   }
}
