#include <16F877A.h>
#device ADC=10                                                             //Define conversor ADC= 10 bits

#FUSES NOWDT                                                               //Desabilita Watch Dog Timer
#FUSES NOLVP                                                               //No low voltage prgming, B3(PIC16) or B5(PIC18) used for I/O
#FUSES NOBROWNOUT                                                          //N�o reseta por queda na tens�o

#use delay(crystal=20000000)                                               //Define clock 20MHz
#use rs232(baud=1200,parity=N,xmit=PIN_C6,rcv=PIN_C7,bits=8,stream=PORT1)  //Configura a porta serial
int16 Sensor1,Sensor2,Tempo;
#INT_RTCC                                                                  //fun��o de chamada do timer 0
void  RTCC_isr(void)                                                       //fun��o do timer 0 ( chama ela sempre que estoura o valor do buffer
{
  if(tempo++>1000)                                                         //Aciona mais ou menos de segundo em segundo       
    {
      output_toggle(pin_d2);                                               //Muda o estado do led(Verifica��o se o programa est� rodando)
      tempo=0;                                                             //Zera a contagem de tempo
    }   
}
void main()                                                               //Fun��o Principal
{
   setup_adc_ports(AN0_AN1_AN3);                                           //Configura o conversor A/D com 3 Canais
   setup_adc(ADC_CLOCK_DIV_2);                                             //COnfigura o clock do conversor A/D
   setup_timer_0(RTCC_INTERNAL|RTCC_DIV_16|RTCC_8_bit);                    //Entra na interrup��o Timer0(RTCC) a cada 819 us                                                                       //
   enable_interrupts(INT_RTCC);
   enable_interrupts(GLOBAL);
   while(TRUE)                                                             //Enquanto for Verdadeiro(Loop Infinito)
   {
      set_adc_channel(0);                                                  //Seleciona o Canal 0
      delay_us(40);                                                        //Aguarda 40us(Tempo para convers�o AD)
      Sensor1=read_adc();                                                  //Salva a leitura do canal 0 em "Sensor1"
      set_adc_channel(1);                                                  //Seleciona o Canal 1
      delay_us(40);                                                        //Aguarda 40us(Tempo para convers�o AD)
      Sensor2=read_adc();                                                  //Salva a leitura do canal 1 em "Sensor2"
      printf("P%lu\n\r",Sensor1);                                          //Escreve os valores na serial
      printf("S%lu\n\r",Sensor2);                                          //Escreve os valores na serial
      delay_us(2000);                                                      //Aguarda 40us(Tempo para convers�o AD)
   }
}
